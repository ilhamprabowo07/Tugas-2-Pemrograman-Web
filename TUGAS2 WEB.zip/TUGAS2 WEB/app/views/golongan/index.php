<h2>
    Daftar Golongan
    <a href="<?php echo URL; ?>/golongan/create" class="btn btn-primary float-end">Golongan Baru</a>
</h2>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>NO</th>
            <th>KODE</th>
            <th>NAMA</th>
            <th>EDIT</th>
            <th>DELETE</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($data['rows'] as $row) { ?>
            <tr>
                <td><?php echo $row['gol_id']; ?></td>
                <td><?php echo $row['gol_kode']; ?></td>
                <td><?php echo $row['gol_nama']; ?></td>
                <td><a href="<?php echo URL; ?>/golongan/edit/" class="btn btn-warning btn-sm float-end">Edit</a></td>
                <td><a href="<?php echo URL; ?>/golongan/delete/" class="btn btn-warning btn-sm float-end">Delete</a></td>
            </tr>
        <?php } ?>
    </tbody>
</table>