<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="<?php echo URL; ?>/layouts/assets/images/favicon.ico" rel="shortcut icon">
	<link rel="stylesheet" href="<?php echo URL; ?>/layouts/assets/css/style.css">
	<title>Tugas 2 Pemrograman Web</title>
</head>

<body>
	<main>
		<header>
			<h2>SISTEM INFORMASI PLN</h2>
		</header>
		<nav>
			<ul>
				<li><a href="<?php echo URL; ?>">Home</a></li>
				<li><a href="<?php echo URL; ?>/kategori">Golongan</a></li>
				<li><a href="<?php echo URL; ?>/produk">Pelanggan</a></li>
				<li><a href="<?php echo URL; ?>/order">User</a></li>
				<li><a href="<?php echo URL; ?>/login">Logout</a></li>
			</ul>
		</nav>

		<section>
			<?php require_once ROOT . "app/views/" . $view . ".php"; ?>
		</section>

		<footer>
			Created &copy; Ilham Prabowo
		</footer>

	</main>
</body>

</html>